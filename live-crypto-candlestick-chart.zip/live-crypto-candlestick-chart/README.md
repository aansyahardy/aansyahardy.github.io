# Live Crypto Candlestick Chart

A Pen created on CodePen.io. Original URL: [https://codepen.io/michaelsboost/pen/YzZwzEj](https://codepen.io/michaelsboost/pen/YzZwzEj).

Thanks to TradingView you get access to very helpful charts for trading/investing in Stocks/Futures/Forex and Cryto.